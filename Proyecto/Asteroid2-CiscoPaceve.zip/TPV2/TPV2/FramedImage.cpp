#include "FramedImage.h"

FramedImage::FramedImage(int w, int h, int frames) : Component()
{
	widthFrame = w;
	heightFrame = h;
	nFrames = frames;
}
