#include "Health.h"
#include "Game.h"
Health::Health(int maxLifes_)
{
	maxLives = maxLifes_;
	lives = maxLifes_;
}